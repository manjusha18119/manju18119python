
e=5
c=1
for a in range(0,e):
	for b in range(0,a):
		print(c, end=" ")
		c=c+1
	print(" ")
