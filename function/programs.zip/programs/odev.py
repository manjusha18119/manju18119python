#4.Write a program check whether the given number is odd or even.
a=int(input("Enter the number: "))
if a%2==0:
	print("Even")
else:
	print("odd")
