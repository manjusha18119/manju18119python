#13. Write a program to calculate the area and perimeter of a rectangle..
length=int(input("Enter the length :"))
breadth=int(input("Enter the length :"))
print("Area =",length*breadth)
print("perimeter =",2*(length+breadth))
