a="*"
for i in range(6):
	print(i*a)
		#i=i-1
for i in range(5,1,-1):
	print(i*a)
print(a)
