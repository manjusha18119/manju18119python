
e=5
for a in range(0,e+1):
	for b in range(0,a):
		print("*", end=" ")
	print(" ")
