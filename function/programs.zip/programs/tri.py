#18. Write a program to  Display Triangle as follow : 
e=int(input("Enter the range:"))
for a in range(0,e+1):
	for b in range(0,a):
		print(a, end=" ")
	print(" ")
