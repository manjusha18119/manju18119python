e=5
c=2
for a in range(0,e):
	for b in range(0,a):
		print(c, end=" ")
		c=c+2
	print(" ")
