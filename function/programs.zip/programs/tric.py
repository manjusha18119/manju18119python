#e=5
c=65
#print(chr(64))
for a in range(65,70):
	for b in range(65,a):
		print(chr(b), end=" ")
		#c=c+1
	print(" ")
