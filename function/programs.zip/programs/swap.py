#2.Write a program to  swap two variables.
a=input("Enter the value of a :")
#a=int(a)
b=input("Enter the value of b :")
#b=int(b)
temp=a
a=b
b=temp
print("swap value of a=",a)
print("swap value of b=",b)


