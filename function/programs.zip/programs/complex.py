# 20. Program to perform Addition,Subtraction,Multiplication and division on Complex-No's.
num1=complex(input("Enter the first complex number:"))
num2=complex(input("Enter the second complex number:"))
num3=num1+num2
print("Addition =",complex(num3))
print("Subtraction =",complex(num1-num2))
print("Multiplication =",complex(num1*num2))
print("Division =",complex(num1+num2))
