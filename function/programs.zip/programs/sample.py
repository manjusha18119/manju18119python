print(10)
