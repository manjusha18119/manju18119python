'''8. Write a program for Printing Odd numbers between 1 and 50 and calculate the sum of that numbers.'''
suma=0
for i in range(1,50,2):
	a=i
	suma=suma+a
print(suma)
