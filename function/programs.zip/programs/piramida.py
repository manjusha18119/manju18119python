a="*"
for i in range(6,1,-1):
	print(i*a)
print(a)
