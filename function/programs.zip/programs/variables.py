#Assigning Values to Variables:
a=5	# a holds integer values
b=3.2	#  b holds floating point value
c="Hello"	# c  holds a string
print(a)
print(b)
print(c)
#Multiple Assignments
x=y=z="same"	# 3 variables x,y,z contains the string 'same'
print(x)
print(y)
print(z)
a,b,c=5,3.2,"Hello" # a=5 ; b=3.2 ; c="Hello"
print(a)
print(b)
print(c)
#Deleting a variable
a=10
del a
#This is a simple Python variable declaration and operation example.
a=10
b=30
sum = a+b
print("sum",sum)
