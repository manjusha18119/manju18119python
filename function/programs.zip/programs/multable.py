#12.Write a program to Display Multiplication Table
digit=int(input("multiplication table of which number ?"))
for i in range(1,11):
	c=digit*i
	print(i,"*",digit,"=",c)

