#1.Write a program to check whether the entered number is postive or negative
a=input("Enter the number:")
a=int(a)
if a>=0:
	print("Entered number is positive")
else:
	print("Entered number is negative")
